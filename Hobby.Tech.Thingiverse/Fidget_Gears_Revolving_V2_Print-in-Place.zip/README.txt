                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3495096
Fidget Gears Revolving V2 Print-in-Place by kasinatorhh is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Update 2019-05-06: have a look at the Remix for 5 gears (to do motor cycling games) https://www.thingiverse.com/thing:3609281
Update 2019-04-26: have a look at the Remix for keychain: https://www.thingiverse.com/thing:3584811
pdate 2019-04-22: added singulated disassembled V7 version. see description below.
Update 2019-04-16: added Print-in-Place HighRes V8E. Successfully tested on Silver ABS from Inofil3D. see comments on used settings.
In case the vertical gears are a little bit too tight (when using ABS) you could put one drop Nail Polish Remover on each Holder-Side and rotate until it's free, Then wash it out using Water. I then used Silicon Oil and it turns freely. V8E has 1mm less distance between big gears and changed the Gear-Twist to be in line with outer gear. Vertical gear moved further to the outside on that design.

Update2019-03-29: added new Print-In-Place HighRes files V7C, successfully tested on Dark-Gold PLA from ICE (assumed worst case)
Used following settings 0.6mm nozzle, 0.15mm layer height, adaptive layers (max Var 0.1, step size 0.01), concentric support, 20% infill, 60% Skin Overlap Percentage, 25mm/s outer wall speed, Print Acceleration 300mm/s², 40s min Layer Time, 100% Fan cooling, Support Overhang angle 85°,  30% Support.

If you really really like the design, use the tip the designer button ;)

After trying several versions, I have two main versions:
<b>Print-In-Place</b>:
Use V8E version. it has gears better to print plus optimized Holder.
1. Print the stl:
-I use 0.6mm nozzle to have good print. 0.4mm is reported working from other makes.
-Concentric Support, 50%, 0mm Z-Distance
-100% infil (you'll need the stability)
-Slow Wall-Speed (20mm/s).
-Optimize your print temperature: If you print too hot, the gears get relics, if you print too cold, the Layers have not enough adhesion.
-Use print cooling, otherwise the material melts back to a "Blob" or sticks together because of being too soft when putting next layer on.
Printed with PLA and ABS.
2. Remove Print Relics
-break off support, make sure the Gear-support removal dosn't break the gears.
In case of ABS glue them back on with Acetone.
-I use a scalpel to disjunct.
-If you don't make it with "V8E", use "V8E with Basic Supports" and find your own optimum support structure. I used intentionally a bit more sticky support, as the vertical gear easily flips over when printing (3/4 prints fail there).

<b>Singulated</b>:
Use V7_Singulated.zip in case your Printer doesn't manage the Print-In-Place. 
1. Print All files from the ZIP file 1x, Shaft once again.
2. Cut-off the print relics (e.g. elephants foot)
3. Put the big gears to the holder with Big-Radius.
4. Make sure the big gears rotate freely on the holder. Use a scalpel or so to fine tune tolerances if needed for your printer
5. make sure the small-gear holes and the Shafts fit together, rotating freely, pull the shaft out again
6. Insert the small gears to the assembly. They fit only into one Gear. If the teeth don't dive in, it's the wrong gear.
7. Put the holder with the small-radius on top.
8. Rotate the Big Gear until you find the hole in the holder aligned with the holes in the gear.
9. Put the shaft into the assembly. Make sure holes still align. Push with e.g. mini-torx-screwdriver (flat edge!)
10. Repeat with the other gear
11. Enjoy playing.

Post a make or leave a note if you like this design!

My first version of me was adding Balls.
Now I added a gear instead, as I mostly played with the "hole fillers"
I wanted them to revolve the gears and finally rotate the other ball.

Be careful not to break off the Holders when blocking the gear (to see how strong they are). Sneak-Preview: NOT that strong.

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: Yes
Resolution: 0.15mm
Infill: 100%
Filament_brand: Innofil3D
Filament_color: Silver/Green/Black
Filament_material: ABS

Notes: 
Printed with 0.6mm nozzle.
I used supports for the Holders, No support for the gears.
Very first version was pinted in Tough PLA, works as well, but my ABS is smoother.