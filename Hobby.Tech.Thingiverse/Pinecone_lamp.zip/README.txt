                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2827592
Pinecone lamp by Streetfire_Industries is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Finally here!

It uses a standard e14 fitting and a rgb led bulb, I've uploaded the bot as a step file so you can change it, just keep the pins the same.

Have fun :3

uses one of these lamps that can change colour: JEDI Lighting LED-lamp E14 3.2 W RGB

Lamp base: https://www.gamma.nl/assortiment/gamma-lamphouder-e14-wit/p/B456237

# Print Settings

Printer: Felix MK7s
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20%, 2 shells/outlines
Filament_brand: doesn't matter
Filament_color: white or other light colours 
Filament_material: PLA

Notes: 
The lighter the material the better the reflection will be and so the effect will be better. I printed this one in white, but also had one in lavender colour which looked cool but the light couldn't really be seen well.