                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3249669
Christmas thealight holder (electronic) by RaimonElctrncs is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Christmas thealight holder (electronic)

Christmas is just around the corner. This model is perfect for the festive season. It's Christmas around the world. Print it as a gift to those special someone. Or print it for your home. I used an electronic thealight inside to light up the holder. A thealight fits nicely into the model. I'm not sure what a real fire-thealight would do; i guess it would melt the print and you end up with a mess?! Let us not find out. The thealight holder has a voronoi diagram, but the model is closed.

Note: the points at the bottom of the model can be sharp.

Best,

Raimon

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: No
Resolution: 0.25
Infill: 10%
Filament_brand: Ultimaker
Filament_color: white
Filament_material: PLA

Notes: 
I have printed this model with Ultimaker White PLA at 70mm/s. I used a brim just to be sure the model would nice stay on the platform. My layerheight was 0.25mm and i used 10% infill.
My extruder had a nice temperature of 210 degrees Celcius, and my printbed was 60 degrees Celcius.